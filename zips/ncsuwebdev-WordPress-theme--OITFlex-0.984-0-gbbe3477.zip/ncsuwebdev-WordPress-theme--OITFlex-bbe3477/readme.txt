= OIT Flex =
Author: OIT Design, Jen Riehle

A child of the Twenty-Eleven theme with a flexible layout, offering style and image options specific to NC State University and falling within the university brand book guidelines. Created by OIT Design.
http://oitdesign.ncsu.edu/

== ABOUT TWENTY ELEVEN ==
http://wordpress.org/extend/themes/twentyeleven
* by the WordPress team, http://wordpress.org/
